from set import Mset 

u = Mset.from_string("(6,13)-{7}")

print(u)
print(8 in u)